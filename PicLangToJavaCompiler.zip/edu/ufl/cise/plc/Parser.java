package edu.ufl.cise.plc;

import edu.ufl.cise.plc.ast.*;

import java.util.ArrayList;
import java.util.List;

public class Parser implements IParser {
    private ILexer lex;
    private IToken t;


    public Parser(String input){
        lex = CompilerComponentFactory.getLexer(input);
    }

    @Override
    public ASTNode parse() throws PLCException {
        t = lex.next();
        Program p = program();
        if (isKind(IToken.Kind.EOF)) {
            return p;
        } else {
            throw new SyntaxException("EOF was not only remaining token.");
        }
    }

    //Program::=
    //	(Type | 'void') IDENT '(' (NameDef ( ',' NameDef)* )? ')'
    //	(  Declaration ';'     |    Statement ';'  )*
    public Program program() throws PLCException {
        IToken first = t;
        Types.Type returnType;
        if (isKind(IToken.Kind.KW_VOID)){
            returnType = Types.Type.VOID;
            consume();
        } else {
            IToken temp = t;
            match(IToken.Kind.TYPE);
            returnType = Types.Type.toType(temp.getText());
        }
        String name = t.getText();
        match(IToken.Kind.IDENT);
        match(IToken.Kind.LPAREN);
        List<NameDef> params = new ArrayList<NameDef>();
        while (!isKind(IToken.Kind.RPAREN)) {
            params.add(nameDef());
            if (isKind(IToken.Kind.COMMA)) {
                consume();
            }
        }
        match(IToken.Kind.RPAREN);
        List<ASTNode> das = new ArrayList<ASTNode>();
        while (isKind(IToken.Kind.KW_WRITE, IToken.Kind.RETURN, IToken.Kind.TYPE, IToken.Kind.IDENT)) {
            if(isKind(IToken.Kind.TYPE)) {
                das.add(declaration());
            } else {
                das.add(statement());
            }
            match(IToken.Kind.SEMI);
        }
        return new Program(first, returnType, name, params, das);
    }

    //NameDef::=
    //	Type ( IDENT | Dimension IDENT )
    public NameDef nameDef() throws PLCException {
        IToken currFirst = t, currTypeToken = t;
        match(IToken.Kind.TYPE);
        if(isKind(IToken.Kind.LSQUARE)) {
            Dimension dim = dimension();
            IToken currNameToken = t;
            match(IToken.Kind.IDENT);
            return new NameDefWithDim(currFirst, currTypeToken, currNameToken, dim);
        }
        IToken currNameToken = t;
        match(IToken.Kind.IDENT);
        return new NameDef(currFirst, currTypeToken, currNameToken);
    }

    //Declaration::=
    //	NameDef (('=' | '<-') Expr)?
    public Declaration declaration() throws PLCException {
        IToken first = t;
        NameDef nd = nameDef();
        if (isKind(IToken.Kind.ASSIGN, IToken.Kind.LARROW)) {
            IToken op = t;
            consume();
            Expr e = expr();
            return new VarDeclaration(first, nd, op, e);
        } else {
            return new VarDeclaration(first, nd, null, null);
        }
    }

    //Statement::=
    //	IDENT PixelSelector? '=' Expr |
    //  IDENT PixelSelector? ‘<-’ Expr |
    //  'write' Expr '->' Expr |
    //	'^' Expr
    public Statement statement() throws PLCException {
        IToken first = t;
        if (isKind(IToken.Kind.IDENT)) {
            String name = t.getText();
            match(IToken.Kind.IDENT);
            PixelSelector ps = null;
            if (isKind(IToken.Kind.LSQUARE)) {
                ps = pixelSelector();
            }
            Expr e;
            if (isKind(IToken.Kind.ASSIGN)) {
                consume();
                e = expr();
                return new AssignmentStatement(first, name, ps, e);
            } else if (isKind(IToken.Kind.LARROW)) {
                consume();
                e = expr();
                return new ReadStatement(first, name, ps, e);
            } else {
                throw new SyntaxException("Illegal read or assignment statement.");
            }
        } else if (isKind(IToken.Kind.KW_WRITE)) {
            consume();
            Expr e1 = expr();
            match(IToken.Kind.RARROW);
            Expr e2 = expr();
            return new WriteStatement(first, e1, e2);
        } else if (isKind(IToken.Kind.RETURN)) {
            consume();
            Expr e = expr();
            return new ReturnStatement(first, e);
        } else {
            throw new SyntaxException("Illegal start to statement.");
        }
    }

    //Expr ::= ConditionalExpr | LogicalOrExpr
    public Expr expr() throws PLCException {
        IToken first = t;
        if (isKind(IToken.Kind.KW_IF)){
            return conditionalExpr();
        }
        else if (isKind(IToken.Kind.BANG, IToken.Kind.MINUS, IToken.Kind.COLOR_OP,
                IToken.Kind.IMAGE_OP, IToken.Kind.BOOLEAN_LIT, IToken.Kind.STRING_LIT,
                IToken.Kind.INT_LIT, IToken.Kind.FLOAT_LIT, IToken.Kind.IDENT, IToken.Kind.LPAREN,
                IToken.Kind.COLOR_CONST, IToken.Kind.LANGLE, IToken.Kind.KW_CONSOLE)) {
            return logicalOrExpr();
        }
        else {
            throw new SyntaxException("Illegal start of expression.", t.getSourceLocation());
        }
    }

    //ConditionalExpr ::= 'if' '(' Expr ')' Expr 'else'  Expr 'fi'
    public ConditionalExpr conditionalExpr() throws PLCException {
        IToken first = t;
        consume(); //consume because func only called if first token is 'if'
        match(IToken.Kind.LPAREN);
        Expr cond = expr();
        match(IToken.Kind.RPAREN);
        Expr tcase = expr();
        match(IToken.Kind.KW_ELSE);
        Expr fcase = expr();
        match(IToken.Kind.KW_FI);
        return new ConditionalExpr(first, cond, tcase, fcase);
    }

    //LogicalOrExpr ::= LogicalAndExpr ( '|' LogicalAndExpr)*
    public Expr logicalOrExpr() throws PLCException {
        IToken first = t;
        Expr l = logicalAndExpr();
        Expr r = null;
        while (isKind(IToken.Kind.OR)){
            IToken bar = t;
            consume();
            r = logicalAndExpr();
            l = new BinaryExpr(first, l, bar, r);
        }
        return l;
    }

    //LogicalAndExpr ::= ComparisonExpr ( '&'  ComparisonExpr)*
    public Expr logicalAndExpr() throws PLCException {
        IToken first = t;
        Expr l = comparisonExpr();
        Expr r = null;
        while (isKind(IToken.Kind.AND)){
            IToken and = t;
            consume();
            r = comparisonExpr();
            l = new BinaryExpr(first, l, and, r);
        }
        return l;
    }

    //ComparisonExpr ::= AdditiveExpr ( ('<' | '>' | '==' | '!=' | '<=' | '>=') AdditiveExpr)*
    public Expr comparisonExpr() throws PLCException {
        IToken first = t;
        Expr l = additiveExpr();
        Expr r = null;
        while (isKind(IToken.Kind.LT, IToken.Kind.GT, IToken.Kind.EQUALS,
                IToken.Kind.NOT_EQUALS, IToken.Kind.LE, IToken.Kind.GE)) {
            IToken op = t;
            consume();
            r = additiveExpr();
            l = new BinaryExpr(first, l, op, r);
        }
        return l;
    }

    //AdditiveExpr ::= MultiplicativeExpr ( ('+'|'-') MultiplicativeExpr )*
    public Expr additiveExpr() throws PLCException {
        IToken first = t;
        Expr l = multiplicativeExpr();
        Expr r = null;
        while (isKind(IToken.Kind.PLUS, IToken.Kind.MINUS)) {
            IToken op = t;
            consume();
            r = multiplicativeExpr();
            l = new BinaryExpr(first, l, op, r);
        }
        return l;
    }

    //MultiplicativeExpr ::= UnaryExpr (('*'|'/' | '%') UnaryExpr)*
    public Expr multiplicativeExpr() throws PLCException {
        IToken first = t;
        Expr l = unaryExpr();
        Expr r = null;
        while (isKind(IToken.Kind.TIMES, IToken.Kind.DIV, IToken.Kind.MOD)){
            IToken op = t;
            consume();
            r = unaryExpr();
            l = new BinaryExpr(first, l, op, r);
        }
        return l;
    }

    //UnaryExpr ::= ('!'|'-'| COLOR_OP | IMAGE_OP) UnaryExpr | UnaryExprPostfix
    public Expr unaryExpr() throws PLCException {
        IToken first = t;
        if (isKind(IToken.Kind.BANG, IToken.Kind.MINUS, IToken.Kind.COLOR_OP, IToken.Kind.IMAGE_OP)) {
            IToken op = t;
            consume();
            Expr e = unaryExpr();
            return new UnaryExpr(first, op, e);
        }
        else {
            return unaryExprPostFix();
        }
    }

    //UnaryExprPostfix::= PrimaryExpr PixelSelector?
    public Expr unaryExprPostFix() throws PLCException {
        IToken first = t;
        Expr prim = primaryExpr();
        if (isKind(IToken.Kind.LSQUARE)) {
            PixelSelector ps = pixelSelector();
            return new UnaryExprPostfix(first, prim, ps);
        }
        else {
            return prim;
        }
    }

    //PrimaryExpr ::=
    //    BOOLEAN_LIT |
    //    STRING_LIT |
    //    INT_LIT |
    //    FLOAT_LIT |
    //    IDENT |
    //    '(' Expr ')' |
    //    ColorConst |                                //yields ColorConstExp
    //    '<<' Expr ',' Expr ',' Expr '>>' |          //yields ColorExpr
    //    'console'                                   //yields ConsoleExpr
    public Expr primaryExpr() throws PLCException {
        IToken first = t;
        if (isKind(IToken.Kind.BOOLEAN_LIT)){
            consume();
            return new BooleanLitExpr(first);
        }
        else if (isKind(IToken.Kind.STRING_LIT)) {
            consume();
            return new StringLitExpr(first);
        }
        else if (isKind(IToken.Kind.INT_LIT)) {
            consume();
            return new IntLitExpr(first);
        }
        else if (isKind(IToken.Kind.FLOAT_LIT)) {
            consume();
            return new FloatLitExpr(first);
        }
        else if (isKind(IToken.Kind.IDENT)) {
            consume();
            return new IdentExpr(first);
        }
        else if (isKind(IToken.Kind.LPAREN)) {
            consume();
            Expr e = expr();
            match(IToken.Kind.RPAREN);
            return e;
        }
        else if (isKind(IToken.Kind.COLOR_CONST)) {
            consume();
            return new ColorConstExpr(first);
        }
        else if (isKind(IToken.Kind.LANGLE)) {
            consume();
            Expr e1 = expr();
            match(IToken.Kind.COMMA);
            Expr e2 = expr();
            match(IToken.Kind.COMMA);
            Expr e3 = expr();
            match(IToken.Kind.RANGLE);
            return new ColorExpr(first, e1, e2, e3);
        }
        else if (isKind(IToken.Kind.KW_CONSOLE)) {
            consume();
            return new ConsoleExpr(first);
        }
        else {
            throw new SyntaxException("Illegal token in primary expression.", first.getSourceLocation());
        }
    }

    //PixelSelector::= '[' Expr ',' Expr ']'
    public PixelSelector pixelSelector() throws PLCException {
        IToken first = t;
        consume();
        Expr x = expr();
        match(IToken.Kind.COMMA);
        Expr y = expr();
        match(IToken.Kind.RSQUARE);
        return new PixelSelector(first, x, y);
    }

    //Dimension::=
    //	'[' Expr ',' Expr ']'
    public Dimension dimension() throws PLCException {
        IToken first = t;
        match(IToken.Kind.LSQUARE);
        Expr le = expr();
        match(IToken.Kind.COMMA);
        Expr re = expr();
        match(IToken.Kind.RSQUARE);
        return new Dimension(first, le, re);
    }





    //kind checking functions
    protected boolean isKind(IToken.Kind kind) {
        return t.getKind() == kind;
    }
    protected boolean isKind(IToken.Kind... kinds) {
        for (IToken.Kind k : kinds) {
            if (k == t.getKind())
                return true;
        }
        return false;
    }

    //iterative functions
    protected void match(IToken.Kind k) throws PLCException {
        if (t.getKind()==k){
            t = lex.next();
        }
        else {
            throw new SyntaxException("Syntax error encountered.", t.getSourceLocation());
        }
    }
    protected void consume() throws PLCException {
        t = lex.next();
    }

}
