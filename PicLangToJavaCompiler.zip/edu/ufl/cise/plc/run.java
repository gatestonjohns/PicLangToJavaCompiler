package edu.ufl.cise.plc;

import edu.ufl.cise.plc.ast.*;
import edu.ufl.cise.plc.runtime.*;
import edu.ufl.cise.plc.runtime.javaCompilerClassLoader.DynamicClassLoader;
import edu.ufl.cise.plc.runtime.javaCompilerClassLoader.DynamicCompiler;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class run {
    public static void main(String[] args) {
        // Get "code" file name from user
        System.out.println("Enter name of \"code\" file (must be a .txt file relevant to current directory):");
        Scanner inScan = new Scanner(System.in);
        String ogCodeFileName = inScan.nextLine();

        // Get contexts of that text file as string
        String ogCode;
        try {
            ogCode = Files.readString(Paths.get(ogCodeFileName));
            System.out.println("\nPicture Language Code as read from the given file:");
            System.out.println("====================================================");
            System.out.println(ogCode);
        } catch (Exception e) {
            System.out.println("Error finding the .txt file specified.\n");
            return;
        }

        // Perform compiler steps
        ASTNode astRoot;
        try {
            // Lex and parse to obtain AST
            astRoot = CompilerComponentFactory.getParser(ogCode).parse();

            // Type check and decorate AST with declaration and type info
            astRoot.visit(CompilerComponentFactory.getTypeChecker(), null);

            // Generate Java code
            String className = ((Program) astRoot).getName();
            String packageName = "edu.ufl.cise.plc.runtime";
            String fullyQualifiedName = packageName + "." + className;
            String javaCode = (String) astRoot.visit(CompilerComponentFactory.getCodeGenerator(packageName), null);

            // Display generated Java code
            System.out.println("\n\nGenerated Java Code created from input:");
            System.out.println("====================================================");
            System.out.println(javaCode);

            // Invoke Java compiler to obtain bytecode
            byte[] byteCode = DynamicCompiler.compile(fullyQualifiedName, javaCode);

            // Load generated classfile and execute its apply method.
            DynamicClassLoader.loadClassAndRunMethod(byteCode, fullyQualifiedName, "apply", null);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
