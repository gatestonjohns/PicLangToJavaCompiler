package edu.ufl.cise.plc;

import org.xml.sax.ext.LexicalHandler;

class Lexer implements ILexer {
    //internal states list
    private enum STATE {
        START,
        HAVE_ZERO,
        IN_INT,
        IN_IDENT,
        HAVE_DOT,
        IN_FLOAT,
        IN_RARROW,
        IN_LARROW,
        IN_EXCLAMATION,
        IN_EQUAL,
        IN_MINUS,
        IN_COMMENT,
        IN_STRING,
        IN_ESCAPE_CHAR
    }

    //member variable of the input source code to be tokenized!
    final private char[] code;
    //current spot on the input buffer
    private int index = 0,
                line = 0,
                column = 0;
    //current state of lexer
    private STATE state;

    //constructor
    public Lexer(String source) {
        code = source.toCharArray();
        state = STATE.START;
    }

    //overridden functions
    @Override
    public IToken next() throws LexicalException {

        //resetting state variable
        state = STATE.START;
        //resetting token variables
        String tokenText = "";
        int tokenLine = line, tokenColumn = column;


        //begin moving through chars indefinitely looking for next token!
        while (true) {
            //check for EOF and if it is reached, return the current token or deliver error
            if (index == code.length) {
                switch (state) {
                    case IN_STRING, IN_ESCAPE_CHAR, HAVE_DOT -> {
                        throw new LexicalException("End of file reached before terminating character of token.");
                    }
                    case HAVE_ZERO, IN_INT -> {
                        //creating an integer to run getIntSize on
                        Token tempToken = new Token(IToken.Kind.INT_LIT, tokenText, tokenLine, tokenColumn);
                        //running integer size test and returning if valid
                        try {
                            tempToken.getIntValue();
                            return tempToken;
                        }
                        //int too big --> lex exception thrown
                        catch (Exception e) {
                            throw new LexicalException("Integer token deemed too large.", tokenLine, tokenColumn);
                        }
                    }
                    case IN_FLOAT -> {
                        Token tempToken = new Token(IToken.Kind.FLOAT_LIT, tokenText, tokenLine, tokenColumn);
                        try {
                            tempToken.getFloatValue();
                            return tempToken;
                        }
                        catch (Exception e) {
                            throw new LexicalException("Float literal appears invalid.", tokenLine, tokenColumn);
                        }
                    }
                    case IN_IDENT -> {
                        IToken.Kind tokenKind = checkIdentifierString(tokenText);
                        return new Token(tokenKind, tokenText, tokenLine, tokenColumn);
                    }
                    case IN_RARROW -> {
                        return new Token(IToken.Kind.GT, tokenText, tokenLine, tokenColumn);
                    }
                    case IN_LARROW -> {
                        return new Token(IToken.Kind.LT, tokenText, tokenLine, tokenColumn);
                    }
                    case IN_MINUS -> {
                        return new Token(IToken.Kind.MINUS, tokenText, tokenLine, tokenColumn);
                    }
                    case IN_EXCLAMATION -> {
                        return new Token(IToken.Kind.BANG, tokenText, tokenLine, tokenColumn);
                    }
                    case IN_EQUAL -> {
                        return new Token(IToken.Kind.ASSIGN, tokenText, tokenLine, tokenColumn);
                    }
                    default -> {
                        return new Token(IToken.Kind.EOF, "", tokenLine, tokenColumn);
                    }
                }
            }

            //get current char
            char c = code[index];

            //traverse DFA tree!
            switch (state) {
                case START -> {
                    switch (c) {
                        //handling string literals
                        case '\"' -> {
                            tokenText += c;
                            state = STATE.IN_STRING;
                            index++;
                            column++;
                        }
                        //handling comments
                        case '#' -> {
                            tokenText += c;
                            state = STATE.IN_COMMENT;
                            index++;
                            column++;
                        }
                        //handling the whitespace/irrelevant escape chars
                        case ' ', '\t', '\r' -> {
                            index++;
                            column++;
                            tokenColumn = column;
                        }
                        //handling newline char (update line and reset column)
                        case '\n' -> {
                            index++;
                            line++;
                            column = 0;
                            tokenLine = line;
                            tokenColumn = column;
                        }
                        //handling '0' digit
                        case '0' -> {
                            tokenText += c;
                            state = STATE.HAVE_ZERO;
                            index++;
                            column++;
                        }
                        //handling non-zero digits
                        case '1', '2', '3', '4', '5', '6', '7', '8', '9' -> {
                            tokenText += c;
                            state = STATE.IN_INT;
                            index++;
                            column++;
                        }
                        case 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                                'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
                                '$', '_' -> {
                            tokenText += c;
                            state = STATE.IN_IDENT;
                            index++;
                            column++;
                        }
                        case '=' -> {
                            tokenText += c;
                            state = STATE.IN_EQUAL;
                            index++;
                            column++;
                        }
                        case '-' -> {
                            tokenText += c;
                            state = STATE.IN_MINUS;
                            index++;
                            column++;
                        }
                        case '!' -> {
                            tokenText += c;
                            state = STATE.IN_EXCLAMATION;
                            index++;
                            column++;
                        }
                        case '>' -> {
                            tokenText += c;
                            state = STATE.IN_RARROW;
                            index++;
                            column++;
                        }
                        case '<' -> {
                            tokenText += c;
                            state = STATE.IN_LARROW;
                            index++;
                            column++;
                        }
                        case '+' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.PLUS, tokenText, tokenLine, tokenColumn);
                        }
                        case '*' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.TIMES, tokenText, tokenLine, tokenColumn);
                        }
                        case '^' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.RETURN, tokenText, tokenLine, tokenColumn);
                        }
                        case ';' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.SEMI, tokenText, tokenLine, tokenColumn);
                        }
                        case '|' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.OR, tokenText, tokenLine, tokenColumn);
                        }
                        case '%' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.MOD, tokenText, tokenLine, tokenColumn);
                        }
                        case ')' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.RPAREN, tokenText, tokenLine, tokenColumn);
                        }
                        case '(' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.LPAREN, tokenText, tokenLine, tokenColumn);
                        }
                        case ']' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.RSQUARE, tokenText, tokenLine, tokenColumn);
                        }
                        case '[' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.LSQUARE, tokenText, tokenLine, tokenColumn);
                        }
                        case '/' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.DIV, tokenText, tokenLine, tokenColumn);
                        }
                        case ',' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.COMMA, tokenText, tokenLine, tokenColumn);
                        }
                        case '&' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.AND, tokenText, tokenLine, tokenColumn);
                        }
                        default -> {
                            throw new LexicalException("Invalid character at the start of token.", line, column);
                        }
                    }
                }
                case HAVE_ZERO -> {
                    switch (c) {
                        case '.' -> {
                            tokenText += c;
                            state = STATE.HAVE_DOT;
                            index++;
                            column++;
                        }
                        default -> {
                            return new Token(IToken.Kind.INT_LIT, tokenText, tokenLine, tokenColumn);
                        }
                    }
                }
                case HAVE_DOT -> {
                    switch (c) {
                        case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' -> {
                            tokenText += c;
                            state = STATE.IN_FLOAT;
                            index++;
                            column++;
                        }
                        default -> {
                            throw new LexicalException("Non-numeric character after a decimal. (Invalid path from HAVE_DOT state.", line, column);
                        }
                    }
                }
                case IN_INT -> {
                    switch (c) {
                        case '.' -> {
                            tokenText += c;
                            state = STATE.HAVE_DOT;
                            index++;
                            column++;
                        }
                        case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' -> {
                            tokenText += c;
                            index++;
                            column++;
                        }
                        default -> {
                            //creating an integer to run getIntSize on
                            Token tempToken = new Token(IToken.Kind.INT_LIT, tokenText, tokenLine, tokenColumn);
                            //running integer size test and returning if valid
                            try {
                                tempToken.getIntValue();
                                return tempToken;
                            }
                            //int too big --> lex exception thrown
                            catch (Exception e) {
                                throw new LexicalException("Integer token deemed too large.", tokenLine, tokenColumn);
                            }
                        }
                    }
                }
                case IN_FLOAT -> {
                    switch (c) {
                        case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' -> {
                            tokenText += c;
                            index++;
                            column++;
                        }
                        default -> {
                            Token tempToken = new Token(IToken.Kind.FLOAT_LIT, tokenText, tokenLine, tokenColumn);
                            try {
                                tempToken.getFloatValue();
                                return tempToken;
                            }
                            catch (Exception e) {
                                throw new LexicalException("Float literal appears invalid.", tokenLine, tokenColumn);
                            }
                        }
                    }
                }
                case IN_IDENT -> {
                    switch (c) {
                        case 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                                'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
                                '$', '_', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' -> {
                            tokenText += c;
                            index++;
                            column++;
                        }
                        default -> {
                            IToken.Kind tokenKind = checkIdentifierString(tokenText);
                            return new Token(tokenKind, tokenText, tokenLine, tokenColumn);
                        }
                    }
                }
                case IN_RARROW -> {
                    switch (c) {
                        case '>' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.RANGLE, tokenText, tokenLine, tokenColumn);
                        }
                        case '=' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.GE, tokenText, tokenLine, tokenColumn);
                        }
                        default -> {
                            return new Token(IToken.Kind.GT, tokenText, tokenLine, tokenColumn);
                        }
                    }

                }
                case IN_LARROW -> {
                    switch (c) {
                        case '<' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.LANGLE, tokenText, tokenLine, tokenColumn);
                        }
                        case '-' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.LARROW, tokenText, tokenLine, tokenColumn);
                        }
                        case '=' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.LE, tokenText, tokenLine, tokenColumn);
                        }
                        default -> {
                            return new Token(IToken.Kind.LT, tokenText, tokenLine, tokenColumn);
                        }
                    }
                }
                case IN_MINUS -> {
                    switch (c) {
                        case '>' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.RARROW, tokenText, tokenLine, tokenColumn);
                        }
                        default -> {
                            return new Token(IToken.Kind.MINUS, tokenText, tokenLine, tokenColumn);
                        }
                    }
                }
                case IN_EXCLAMATION -> {
                    switch (c) {
                        case '=' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.NOT_EQUALS, tokenText, tokenLine, tokenColumn);
                        }
                        default -> {
                            return new Token(IToken.Kind.BANG, tokenText, tokenLine, tokenColumn);
                        }
                    }
                }
                case IN_EQUAL -> {
                    switch (c) {
                        case '=' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.EQUALS, tokenText, tokenLine, tokenColumn);
                        }
                        default -> {
                            return new Token(IToken.Kind.ASSIGN, tokenText, tokenLine, tokenColumn);
                        }
                    }
                }
                case IN_STRING -> {
                    switch (c) {
                        case '\\' -> {
                            tokenText += c;
                            state = STATE.IN_ESCAPE_CHAR;
                            index++;
                            column++;
                        }
                        case '\"' -> {
                            tokenText += c;
                            index++;
                            column++;
                            return new Token(IToken.Kind.STRING_LIT, tokenText, tokenLine, tokenColumn);
                        }
                        default -> {
                            tokenText += c;
                            index++;
                            column++;
                        }
                    }
                }
                case IN_ESCAPE_CHAR -> {
                    switch (c) {
                        case 'b','t','f','n','r','\"', '\'', '\\' -> {
                            tokenText += c;
                            state = STATE.IN_STRING;
                            index++;
                            column++;
                        }
                        default -> {
                            throw new LexicalException("Lexer faced an invalid character after a backslash in a string.", line, column);
                        }
                    }
                }
                case IN_COMMENT -> {
                    switch (c) {
                        case '\n' -> {
                            tokenText += c;
                            index++;
                            line++;
                            column = 0;
                            return this.next();
                        }
                        default -> {
                            tokenText += c;
                            index++;
                            column++;
                        }
                    }
                }
                //error case:
                default -> {
                    throw new LexicalException("Somehow the lexer is not in any of the defined states of the switch statement.", line, column);
                }
            }
        }

    }

    @Override
    public IToken peek() throws LexicalException {
        //SAVE current object vars like index, line, column and state
        int startInd = index, startLine = line, startColumn = column;

        //create a temp token variable and initialize it with "this.next()" function
        Token tempToken = (Token) this.next();

        //return the member variables to the pre-saved values of index, line, column and state
        index = startInd;
        line = startLine;
        column = startColumn;

        //return temp token variable
        return tempToken;
    }

    //helper function to test for reserved word
    private IToken.Kind checkIdentifierString(String str){
        switch (str) {
            case "string","int","float","boolean","color","image" -> {
                return IToken.Kind.TYPE;
            }
            case "getWidth", "getHeight" -> {
                return IToken.Kind.IMAGE_OP;
            }
            case "BLACK","BLUE","CYAN","DARK_GRAY","GRAY","GREEN","LIGHT_GRAY",
                    "MAGENTA","ORANGE","PINK","RED","WHITE","YELLOW" -> {
                return IToken.Kind.COLOR_CONST;
            }
            case "true","false" -> {
                return IToken.Kind.BOOLEAN_LIT;
            }
            case "if" -> {
                return IToken.Kind.KW_IF;
            }
            case "else" -> {
                return IToken.Kind.KW_ELSE;
            }
            case "fi" -> {
                return IToken.Kind.KW_FI;
            }
            case "write" -> {
                return IToken.Kind.KW_WRITE;
            }
            case "console" -> {
                return IToken.Kind.KW_CONSOLE;
            }
            case "void" -> {
                return IToken.Kind.KW_VOID;
            }
            case "getRed","getGreen","getBlue" -> {
                return IToken.Kind.COLOR_OP;
            }
            default -> {
                return IToken.Kind.IDENT;
            }
        }
    }

}
