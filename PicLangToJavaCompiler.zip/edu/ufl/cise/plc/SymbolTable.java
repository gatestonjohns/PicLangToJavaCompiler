package edu.ufl.cise.plc;

import java.util.*;

import edu.ufl.cise.plc.ast.Types.Type;
import edu.ufl.cise.plc.ast.*;

//everything is global except pixel selector values on left hand side of assignment

public class SymbolTable {
    //because local vars cannot be named the same as pre-existing global vars,
    //there is no need for a scope-tracking variable. [All IDENTs unique.]
    private HashMap<String, Declaration> symTab = new HashMap<>();

    public boolean addIdent(String newIdent, Declaration newDec) {
        //check to ensure not previously defined
        if (symTab.containsKey(newIdent))
            return false;
        //otherwise, add to symbol table
        else {
            symTab.put(newIdent, newDec);
            return true;
        }
    }

    public boolean identExists(String targetIdent) {
        return symTab.containsKey(targetIdent);
    }

    public void removeIdent(String trash) {
        symTab.remove(trash);
    }

    public Type getIdentType(String targetIdent) {
        return symTab.get(targetIdent).getType();
    }

    public Declaration getDec(String targetIdent) { return symTab.get(targetIdent); }

}
