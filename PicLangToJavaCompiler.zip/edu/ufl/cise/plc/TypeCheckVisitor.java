package edu.ufl.cise.plc;

import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.ufl.cise.plc.IToken.Kind;
import edu.ufl.cise.plc.ast.ASTNode;
import edu.ufl.cise.plc.ast.ASTVisitor;
import edu.ufl.cise.plc.ast.AssignmentStatement;
import edu.ufl.cise.plc.ast.BinaryExpr;
import edu.ufl.cise.plc.ast.BooleanLitExpr;
import edu.ufl.cise.plc.ast.ColorConstExpr;
import edu.ufl.cise.plc.ast.ColorExpr;
import edu.ufl.cise.plc.ast.ConditionalExpr;
import edu.ufl.cise.plc.ast.ConsoleExpr;
import edu.ufl.cise.plc.ast.Declaration;
import edu.ufl.cise.plc.ast.Dimension;
import edu.ufl.cise.plc.ast.Expr;
import edu.ufl.cise.plc.ast.FloatLitExpr;
import edu.ufl.cise.plc.ast.IdentExpr;
import edu.ufl.cise.plc.ast.IntLitExpr;
import edu.ufl.cise.plc.ast.NameDef;
import edu.ufl.cise.plc.ast.NameDefWithDim;
import edu.ufl.cise.plc.ast.PixelSelector;
import edu.ufl.cise.plc.ast.Program;
import edu.ufl.cise.plc.ast.ReadStatement;
import edu.ufl.cise.plc.ast.ReturnStatement;
import edu.ufl.cise.plc.ast.StringLitExpr;
import edu.ufl.cise.plc.ast.Types.Type;
import edu.ufl.cise.plc.ast.UnaryExpr;
import edu.ufl.cise.plc.ast.UnaryExprPostfix;
import edu.ufl.cise.plc.ast.VarDeclaration;
import edu.ufl.cise.plc.ast.WriteStatement;

import static edu.ufl.cise.plc.ast.Types.Type.*;

public class TypeCheckVisitor implements ASTVisitor {

	SymbolTable symbolTable = new SymbolTable();  
	Program root;
	
	record Pair<T0,T1>(T0 t0, T1 t1){};  //may be useful for constructing lookup tables.
	
	private void check(boolean condition, ASTNode node, String message) throws TypeCheckException {
		if (!condition) {
			throw new TypeCheckException(message, node.getSourceLoc());
		}
	}
	
	//The type of a BooleanLitExpr is always BOOLEAN.  
	//Set the type in AST Node for later passes (code generation)
	//Return the type for convenience in this visitor.  
	@Override
	public Object visitBooleanLitExpr(BooleanLitExpr booleanLitExpr, Object arg) throws Exception {
		booleanLitExpr.setType(Type.BOOLEAN);
		return BOOLEAN;
	}

	@Override
	public Object visitStringLitExpr(StringLitExpr stringLitExpr, Object arg) throws Exception {
		stringLitExpr.setType(STRING);
		return STRING;
	}

	@Override
	public Object visitIntLitExpr(IntLitExpr intLitExpr, Object arg) throws Exception {
		intLitExpr.setType(INT);
		return INT;
	}

	@Override
	public Object visitFloatLitExpr(FloatLitExpr floatLitExpr, Object arg) throws Exception {
		floatLitExpr.setType(FLOAT);
		return FLOAT;
	}

	@Override
	public Object visitColorConstExpr(ColorConstExpr colorConstExpr, Object arg) throws Exception {
		colorConstExpr.setType(COLOR);
		return COLOR;
	}

	@Override
	public Object visitConsoleExpr(ConsoleExpr consoleExpr, Object arg) throws Exception {
		consoleExpr.setType(CONSOLE);
		return CONSOLE;
	}
	
	//Visits the child expressions to get their type (and ensure they are correctly typed)
	//then checks the given conditions.
	@Override
	public Object visitColorExpr(ColorExpr colorExpr, Object arg) throws Exception {
		Type redType = (Type) colorExpr.getRed().visit(this, arg);
		Type greenType = (Type) colorExpr.getGreen().visit(this, arg);
		Type blueType = (Type) colorExpr.getBlue().visit(this, arg);
		check(redType == greenType && redType == blueType, colorExpr, "color components must have same type");
		check(redType == Type.INT || redType == Type.FLOAT, colorExpr, "color component type must be int or float");
		Type exprType = (redType == Type.INT) ? Type.COLOR : Type.COLORFLOAT;
		colorExpr.setType(exprType);
		return exprType;
	}	


	//Maps forms a lookup table that maps an operator expression pair into result type.  
	//This more convenient than a long chain of if-else statements. 
	//Given combinations are legal; if the operator expression pair is not in the map, it is an error. 
	Map<Pair<Kind,Type>, Type> unaryExprs = Map.of(
			new Pair<Kind,Type>(Kind.BANG,BOOLEAN), BOOLEAN,
			new Pair<Kind,Type>(Kind.MINUS, FLOAT), FLOAT,
			new Pair<Kind,Type>(Kind.MINUS, INT),INT,
			new Pair<Kind,Type>(Kind.COLOR_OP,INT), INT,
			new Pair<Kind,Type>(Kind.COLOR_OP,COLOR), INT,
			new Pair<Kind,Type>(Kind.COLOR_OP,IMAGE), IMAGE,
			new Pair<Kind,Type>(Kind.IMAGE_OP,IMAGE), INT
			);
	//Visits the child expression to get the type, then uses the above table to determine the result type
	//and check that this node represents a legal combination of operator and expression type. 
	@Override
	public Object visitUnaryExpr(UnaryExpr unaryExpr, Object arg) throws Exception {
		// !, -, getRed, getGreen, getBlue
		Kind op = unaryExpr.getOp().getKind();
		Type exprType = (Type) unaryExpr.getExpr().visit(this, arg);
		//Use the lookup table above to both check for a legal combination of operator and expression
		//and to get result type.
		Type resultType = unaryExprs.get(new Pair<Kind,Type>(op,exprType));
		check(resultType != null, unaryExpr, "incompatible types for unaryExpr");
		//Save the type of the unary expression in the AST node for use in code generation later. 
		unaryExpr.setType(resultType);
		//return the type for convenience in this visitor.
		return resultType;
	}


	//This method has several cases. Work incrementally and test as you go. 
	@Override
	public Object visitBinaryExpr(BinaryExpr binaryExpr, Object arg) throws Exception {
		//determine argument (l/r) types
		Type l = (Type) binaryExpr.getLeft().visit(this, arg);
		Type r = (Type) binaryExpr.getRight().visit(this, arg);

		//check: any IdentExprs are previously initialized
		if (binaryExpr.getLeft() instanceof IdentExpr) {
			check(((IdentExpr) binaryExpr.getLeft()).getDec().isInitialized(), binaryExpr.getLeft(),
					"left term of binary expr not previously initialized");
		}
		if (binaryExpr.getRight() instanceof IdentExpr) {
			check(((IdentExpr) binaryExpr.getRight()).getDec().isInitialized(), binaryExpr.getRight(),
					"right term of binary expr not previously initialized");
		}

		//operator decides general case first, then arguments decide specific:
		switch (binaryExpr.getOp().getKind()) {
			case AND, OR -> {
				check(l == BOOLEAN && r == BOOLEAN, binaryExpr, "AND/OR used on non-boolean arguments");
				binaryExpr.setType(BOOLEAN);
				return BOOLEAN;
			}
			case EQUALS, NOT_EQUALS -> {
				check(l == r, binaryExpr, "equality check tried on differing types");
				binaryExpr.setType(BOOLEAN);
				return BOOLEAN;
			}
			case PLUS, MINUS -> {
				if (l == INT && r == INT) {
					binaryExpr.setType(INT);
					return INT;
				}
				else if (l == FLOAT && r == FLOAT) {
					binaryExpr.setType(FLOAT);
					return FLOAT;
				}
				else if (l == INT && r == FLOAT) {
					binaryExpr.getLeft().setCoerceTo(FLOAT);
					binaryExpr.setType(FLOAT);
					return FLOAT;
				}
				else if (l == FLOAT && r == INT) {
					binaryExpr.getRight().setCoerceTo(FLOAT);
					binaryExpr.setType(FLOAT);
					return FLOAT;
				}
				else if (l == COLOR && r == COLOR) {
					binaryExpr.setType(COLOR);
					return COLOR;
				}
				else if (l == COLORFLOAT && r == COLORFLOAT) {
					binaryExpr.setType(COLORFLOAT);
					return COLORFLOAT;
				}
				else if (l == COLORFLOAT && r == COLOR) {
					binaryExpr.getRight().setCoerceTo(COLORFLOAT);
					binaryExpr.setType(COLORFLOAT);
					return COLORFLOAT;
				}
				else if (l == COLOR && r == COLORFLOAT) {
					binaryExpr.getLeft().setCoerceTo(COLORFLOAT);
					binaryExpr.setType(COLORFLOAT);
					return COLORFLOAT;
				}
				else if (l == IMAGE && r == IMAGE) {
					binaryExpr.setType(IMAGE);
					return IMAGE;
				}
				else
					throw new TypeCheckException("illegal arguments to + or - binary expr", binaryExpr.getSourceLoc());
			}
			case TIMES, DIV, MOD -> {
				if (l == INT && r == INT) {
					binaryExpr.setType(INT);
					return INT;
				}
				else if (l == FLOAT && r == FLOAT) {
					binaryExpr.setType(FLOAT);
					return FLOAT;
				}
				else if (l == INT && r == FLOAT) {
					binaryExpr.getLeft().setCoerceTo(FLOAT);
					binaryExpr.setType(FLOAT);
					return FLOAT;
				}
				else if (l == FLOAT && r == INT) {
					binaryExpr.getRight().setCoerceTo(FLOAT);
					binaryExpr.setType(FLOAT);
					return FLOAT;
				}
				else if (l == COLOR && r == COLOR) {
					binaryExpr.setType(COLOR);
					return COLOR;
				}
				else if (l == COLORFLOAT && r == COLORFLOAT) {
					binaryExpr.setType(COLORFLOAT);
					return COLORFLOAT;
				}
				else if (l == COLORFLOAT && r == COLOR) {
					binaryExpr.getRight().setCoerceTo(COLORFLOAT);
					binaryExpr.setType(COLORFLOAT);
					return COLORFLOAT;
				}
				else if (l == COLOR && r == COLORFLOAT) {
					binaryExpr.getLeft().setCoerceTo(COLORFLOAT);
					binaryExpr.setType(COLORFLOAT);
					return COLORFLOAT;
				}
				else if (l == IMAGE && r == IMAGE) {
					binaryExpr.setType(IMAGE);
					return IMAGE;
				}
				//extra cases specific to this switch case
				else if (l == IMAGE && ( r == INT || r == FLOAT )) {
					binaryExpr.setType(IMAGE);
					return IMAGE;
				}
				else if (l == INT && r == COLOR) {
					binaryExpr.getLeft().setCoerceTo(COLOR);
					binaryExpr.setType(COLOR);
					return COLOR;
				}
				else if (l == COLOR && r == INT) {
					binaryExpr.getRight().setCoerceTo(COLOR);
					binaryExpr.setType(COLOR);
					return COLOR;
				}
				else if ((l == FLOAT && r == COLOR) || (l == COLOR && r == FLOAT)) {
					binaryExpr.getLeft().setCoerceTo(COLORFLOAT);
					binaryExpr.getRight().setCoerceTo(COLORFLOAT);
					binaryExpr.setType(COLORFLOAT);
					return COLORFLOAT;
				}
				else
					throw new TypeCheckException("illegal arguments to *,/ or % binary expr", binaryExpr.getSourceLoc());
			}
			case LT,LE,GT,GE -> {
				if ((l == INT && r == INT) || (l == FLOAT && r == FLOAT)) {
					binaryExpr.setType(BOOLEAN);
					return BOOLEAN;
				}
				else if (l == INT && r == FLOAT) {
     				binaryExpr.getLeft().setCoerceTo(FLOAT);
					binaryExpr.setType(BOOLEAN);
					return BOOLEAN;
				}
				else if (l == FLOAT && r == INT) {
					binaryExpr.getRight().setCoerceTo(FLOAT);
					binaryExpr.setType(BOOLEAN);
					return BOOLEAN;
				}
				else
					throw new TypeCheckException("illegal arguments for binary comparison operator [<,<=,>,>=]", binaryExpr.getSourceLoc());
			}
			default ->
				throw new TypeCheckException("invalid operator kind for binaryExpr", binaryExpr.getSourceLoc());
		}
	}


	@Override
	public Object visitIdentExpr(IdentExpr identExpr, Object arg) throws Exception {
		//check: has been declared
		check(symbolTable.identExists(identExpr.getText()), identExpr,
				"visited IdentExpr that was not previously declared");

		//tie dec to node
		identExpr.setDec(symbolTable.getDec(identExpr.getText()));

		//set type to node
		identExpr.setType(identExpr.getDec().getType());

		return identExpr.getType();
	}


	@Override
	public Object visitConditionalExpr(ConditionalExpr conditionalExpr, Object arg) throws Exception {
		//check that condition is boolean type
		Type condType = (Type) conditionalExpr.getCondition().visit(this, arg);
		check(condType == Type.BOOLEAN, conditionalExpr.getCondition(), "condition for if statement is not of type boolean");
		//check both possible cases are of same type
		Type trueType = (Type) conditionalExpr.getTrueCase().visit(this, arg);
		Type falseType = (Type) conditionalExpr.getFalseCase().visit(this, arg);
		check(trueType == falseType, conditionalExpr.getFalseCase(), "true and false case of if statement are of different types");
		//set type of entire conditional
		conditionalExpr.setType(trueType);
		return trueType;
	}


	@Override
	public Object visitDimension(Dimension dimension, Object arg) throws Exception {
		//get types of both arguments
		Type w = (Type) dimension.getWidth().visit(this, arg);
		Type h = (Type) dimension.getHeight().visit(this, arg);

		//check: both are INT
		check(w == INT && h == INT, dimension, "dimension found with non-INT args");

		return null;
	}


	@Override
	//This method can only be used to check PixelSelector objects on the right hand side of an assignment. 
	//Otherwise, check fields from parent assignment statement.
	public Object visitPixelSelector(PixelSelector pixelSelector, Object arg) throws Exception {
		//get x and y expr types
		Type xType = (Type) pixelSelector.getX().visit(this, arg);
		Type yType = (Type) pixelSelector.getY().visit(this, arg);

		//check: both expr are type INT
		check(xType == Type.INT, pixelSelector.getX(), "only ints as pixel selector components (x)");
		check(yType == Type.INT, pixelSelector.getY(), "only ints as pixel selector components (y)");
		return null;
	}


	@Override
	//This method several cases--you don't have to implement them all at once.
	//Work incrementally and systematically, testing as you go.  
	public Object visitAssignmentStatement(AssignmentStatement assignmentStatement, Object arg) throws Exception {
		//get declaration and type of lhs
		check(symbolTable.identExists(assignmentStatement.getName()), assignmentStatement,
				"var on left side of assignment is not previously declared");
		Declaration targetDec = symbolTable.getDec(assignmentStatement.getName());
		assignmentStatement.setTargetDec(targetDec);
		Type targetType = targetDec.getType();

		//case for non-image target
		if (targetType != IMAGE) {
			//check: NO PixelSelector
			check(assignmentStatement.getSelector() == null, assignmentStatement.getSelector(),
					"PixelSelector found on non-image type in assignment statement");

			//get type of rhs
			Type rhsType = (Type) assignmentStatement.getExpr().visit(this, arg);
			//check: type compatible ? if not, COERCE //TODO:: this could be a lot cleaner
			if (targetType == rhsType) {
				targetDec.setInitialized(true);
				return null;
			}
			else if (targetType == INT && rhsType == FLOAT) {
				assignmentStatement.getExpr().setCoerceTo(INT);
				targetDec.setInitialized(true);
				return null;
			}
			else if (targetType == FLOAT && rhsType == INT) {
				assignmentStatement.getExpr().setCoerceTo(FLOAT);
				targetDec.setInitialized(true);
				return null;
			}
			else if (targetType == INT && rhsType == COLOR) {
				assignmentStatement.getExpr().setCoerceTo(INT);
				targetDec.setInitialized(true);
				return null;
			}
			else if (targetType == COLOR && rhsType == INT) {
				assignmentStatement.getExpr().setCoerceTo(COLOR);
				targetDec.setInitialized(true);
				return null;
			}
			else
				throw new TypeCheckException("incompatible non-image types in assignment statement", assignmentStatement.getSourceLoc());

		}
		//case for IMAGE target (without PS)
		else if (assignmentStatement.getSelector() == null) {
			//get type of rhs
			Type rhsType = (Type) assignmentStatement.getExpr().visit(this, arg);

			if (rhsType == IMAGE || rhsType == COLOR || rhsType == COLORFLOAT) {
				targetDec.setInitialized(true);
				return null;
			}
			else if (rhsType == INT) {
				assignmentStatement.getExpr().setCoerceTo(COLOR);
				targetDec.setInitialized(true);
				return null;
			}
			else if (rhsType == FLOAT) {
				assignmentStatement.getExpr().setCoerceTo(COLORFLOAT);
				targetDec.setInitialized(true);
				return null;
			}
			else throw new TypeCheckException("incompatible rhs type assigning an image type (no PS)", assignmentStatement.getSourceLoc());
		}
		//case for IMAGE[,] target (with PS)
		else {
			//get x and y expr
			Expr x = assignmentStatement.getSelector().getX();
			Expr y = assignmentStatement.getSelector().getY();

			//check: both of type IdentExpr
			check(x instanceof IdentExpr && y instanceof IdentExpr, assignmentStatement.getSelector(),
					"arguments of lhs PS of assnStmt are not IdentExpr");

			//get names of both vars
			String xName = x.getText();
			String yName = y.getText();

			//attempt to add them to symbol table
			Declaration xDec = new NameDef(x.getFirstToken(), "int", xName);
			Declaration	yDec = new NameDef(y.getFirstToken(), "int", yName);
			xDec.setInitialized(true);
			yDec.setInitialized(true);
			boolean addedX = symbolTable.addIdent(xName, xDec);
			boolean addedY = symbolTable.addIdent(yName, yDec);
			//check: x,y added as locals
			check(addedX && addedY, assignmentStatement.getSelector(),
					"failed to add new local vars, already declared");

			//visit to assign int type implicitly
			x.visit(this, arg);
			y.visit(this, arg);

			//get type of rhs
			Type rhsType = (Type) assignmentStatement.getExpr().visit(this, arg);

			//check: rhs type == ( COLOR || COLORFLOAT || FLOAT || INT )
			if (rhsType == COLOR) {
				targetDec.setInitialized(true);
			}
			else if (rhsType == COLORFLOAT || rhsType == FLOAT || rhsType == INT) {
				assignmentStatement.getExpr().setCoerceTo(COLOR);
				targetDec.setInitialized(true);
			}
			else throw new TypeCheckException("incompatible rhs type assigning an image[,] type (w/ PS)",
						assignmentStatement.getSourceLoc());

			//delete local vars
			symbolTable.removeIdent(xName);
			symbolTable.removeIdent(yName);

			return null;
		}
	}


	@Override
	public Object visitWriteStatement(WriteStatement writeStatement, Object arg) throws Exception {
		//check: destination Type = ( STRING || CONSOLE )
		Type destType = (Type) writeStatement.getDest().visit(this, arg);
		check(destType == Type.STRING || destType == Type.CONSOLE, writeStatement,
				"illegal destination type for write");
		//check: source Type != CONSOLE
		Type sourceType = (Type) writeStatement.getSource().visit(this, arg);
		check(sourceType != Type.CONSOLE, writeStatement, "illegal source type for write");
		return null;
	}


	@Override
	// TODO :: done?
	public Object visitReadStatement(ReadStatement readStatement, Object arg) throws Exception {
		//check: variable previously declared
		String targetIdent = readStatement.getName();
		check(symbolTable.identExists(targetIdent), readStatement, "read statement references undeclared var");

		//check: NO PixelSelector
		check(readStatement.getSelector() == null, readStatement.getSelector(),
				"encountered read statement with PixelSelector");

		//check: rhs type = ( STRING || CONSOLE )
		Type rhsType = (Type) readStatement.getSource().visit(this, arg);
		check(rhsType == STRING || rhsType == CONSOLE, readStatement.getSource(),
				"rhs of read statement is not type CONSOLE or STRING");

		//get lhs type and coerce CONSOLE rhs types
		Type lhsType = symbolTable.getIdentType(targetIdent);
		if (rhsType == CONSOLE) {
			readStatement.getSource().setCoerceTo(lhsType);
		}

		//initialize target var
		symbolTable.getDec(targetIdent).setInitialized(true);

		//set dec for this read statement
		readStatement.setTargetDec(symbolTable.getDec(targetIdent));

		return null;
	}


	@Override
	public Object visitVarDeclaration(VarDeclaration declaration, Object arg) throws Exception {
		//get target type
		Type targetType = (Type) declaration.getNameDef().visit(this, arg);

		//check: for initialization
		boolean gettingInitialized = declaration.getOp() != null;

		//check: nameDef has DIM | it is initialized IMAGE
		check((declaration.getNameDef() instanceof NameDefWithDim) || !(targetType == IMAGE && !gettingInitialized), declaration,
				"image variable declared in VarDec w/o initialization or dimension");


		//if initialized: get rhs type and check compatibility
		if (gettingInitialized) {
			declaration.getNameDef().setInitialized(true);
			Type rhsType = (Type) declaration.getExpr().visit(this, arg);
			//check right side is initialized if it is a variable
			if (declaration.getExpr() instanceof IdentExpr) {
				check(((IdentExpr) declaration.getExpr()).getDec().isInitialized(), declaration.getExpr(),
						"IdentExpr on right side of varDec not previously initialized");
			}
			switch (declaration.getOp().getKind()) {
				case ASSIGN -> {
					//case for non-image target
					if (targetType != IMAGE) {
						//TODO ?? check: NO PixelSelector
						//check: type compatible ? if not, COERCE
						if (targetType == rhsType) {
							return null;
						} else if (targetType == INT && rhsType == FLOAT) {
							declaration.getExpr().setCoerceTo(INT);
						} else if (targetType == FLOAT && rhsType == INT) {
							declaration.getExpr().setCoerceTo(FLOAT);
						} else if (targetType == INT && rhsType == COLOR) {
							declaration.getExpr().setCoerceTo(INT);
						} else if (targetType == COLOR && rhsType == INT) {
							declaration.getExpr().setCoerceTo(COLOR);
						} else
							throw new TypeCheckException("incompatible non-image types in assn varDec", declaration.getSourceLoc());

					}
					//case for IMAGE type target
					else {
						if (rhsType == IMAGE || rhsType == COLOR || rhsType == COLORFLOAT) {
							return null;
						} else if (rhsType == INT) {
							declaration.getExpr().setCoerceTo(COLOR);
						} else if (rhsType == FLOAT) {
							declaration.getExpr().setCoerceTo(COLORFLOAT);
						} else
							throw new TypeCheckException("incompatible rhs type assigning an image type in varDec", declaration.getSourceLoc());
					}
				}
				case LARROW -> {
					//check: rhs type = ( STRING || CONSOLE )
					check(rhsType == STRING || rhsType == CONSOLE, declaration.getExpr(),
							"rhs of read statement is not type CONSOLE or STRING");

					//if rhs type is console, must COERCE
					if (rhsType == CONSOLE) {
						declaration.getExpr().setCoerceTo(targetType);
					}
				}
			}
		}

		return targetType;
	}


	@Override
	public Object visitProgram(Program program, Object arg) throws Exception {
		//Save root of AST so return type can be accessed in return statements
		root = program;

		//Go through params list
		List<NameDef> params = program.getParams();
		for (NameDef NDnode : params) {
			NDnode.setInitialized(true);
			NDnode.visit(this, arg);
		}
		
		//Check declarations and statements
		List<ASTNode> decsAndStatements = program.getDecsAndStatements();
		for (ASTNode DASnode : decsAndStatements) {
			DASnode.visit(this, arg);
		}
		return program;
	}


	@Override
	public Object visitNameDef(NameDef nameDef, Object arg) throws Exception {
		//attempt to add new var and its declaration to symbol table
		boolean gotAdded = symbolTable.addIdent(nameDef.getName(), nameDef);

		//make sure it got added
		check(gotAdded, nameDef, "attempt to add pre-existing nameDef");
		return nameDef.getType();
	}


	@Override
	public Object visitNameDefWithDim(NameDefWithDim nameDefWithDim, Object arg) throws Exception {
		//check dimension has INT args
		nameDefWithDim.getDim().visit(this, arg);

		//attempt to add it to symbol table
		boolean gotAdded = symbolTable.addIdent(nameDefWithDim.getName(), nameDefWithDim);
		//make sure it got added
		check(gotAdded, nameDefWithDim, "attempt to add pre-existing nameDefWithDim");

		return nameDefWithDim.getType();
	}


	@Override
	public Object visitReturnStatement(ReturnStatement returnStatement, Object arg) throws Exception {
		//check: return type == expression type
		Type returnType = root.getReturnType();
		Type expressionType = (Type) returnStatement.getExpr().visit(this, arg);
		check(returnType == expressionType, returnStatement, "return statement with invalid type");
		//check: if var, was previously initialized
		if (returnStatement.getExpr() instanceof IdentExpr) {
			check(((IdentExpr) returnStatement.getExpr()).getDec().isInitialized(), returnStatement.getExpr(),
					"trying to return an uninitialized IDENT");
		}
		return null;
	}


	@Override
	public Object visitUnaryExprPostfix(UnaryExprPostfix unaryExprPostfix, Object arg) throws Exception {
		//ensure that the expr is of image type
		Type exprType = (Type) unaryExprPostfix.getExpr().visit(this, arg);
		check(exprType == Type.IMAGE, unaryExprPostfix, "pixel selector can only be applied to image");
		//check pixel selector has INT types
		unaryExprPostfix.getSelector().visit(this, arg);
		//set types for overall unaryExprPostfix
		unaryExprPostfix.setType(INT);
		unaryExprPostfix.setCoerceTo(COLOR);
		return COLOR;
	}

}
