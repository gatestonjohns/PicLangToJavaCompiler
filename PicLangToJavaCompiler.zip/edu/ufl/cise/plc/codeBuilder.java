package edu.ufl.cise.plc;

import java.util.*;

public class codeBuilder {
    private String pkgName;
    private String className;
    private String rType;
    private Vector<String> params = new Vector<>();
    private Vector<String> imports = new Vector<>();
    private Vector<String> decs_stmts = new Vector<>();

    //get the entire put together code string
    public String getFinalCode() {
        String finalCode = "";

        //set package at top of code
        if (pkgName != "") {
            finalCode = "package " + pkgName + ";\n";
        }

        //import all necessary packages
        for (String i : imports) {
            finalCode += "import " + i + ";\n";
        }

        //establish the class header
        finalCode += "public class " + className + " {\n";

        //establish the internal apply function
        finalCode += "     public static " + rType + " apply(";

        //insert all parameters
        for (int i = 0; i < params.size(); i++) {
            finalCode += params.elementAt(i);
            if (i < params.size() - 1) {
                finalCode += ", ";
            }
        }

        //close parameter list and open brackets
        finalCode += ") {\n";

        //add decs and statements
        for (String ds : decs_stmts) {
            finalCode += "          " + ds + ";\n";
        }

        //close out apply and class
        finalCode += "     }\n}";

        return finalCode;
    }

    //constructor that also initializes with package
    codeBuilder(String pkgName) {
        this.pkgName = pkgName;
    }

    //modifying functions
    void setClassName(String newCN) {
        this.className = newCN;
    }
    void setReturnType(String newRT) {
        this.rType = newRT;
    }
    void addParam(String newParam) {
        this.params.add(newParam);
    }
    void addImportTarget(String toImport) {
        //check so that we are not importing redundantly
        for (String curr : imports) {
            if (Objects.equals(curr, toImport)) {
                return;
            }
        }
        //not previously added, so add
        this.imports.add(toImport);
    }
    void addDecOrStatement(String newDS) {
        this.decs_stmts.add(newDS);
    }
}
