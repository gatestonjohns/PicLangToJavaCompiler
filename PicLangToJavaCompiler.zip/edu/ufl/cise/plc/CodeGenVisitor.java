package edu.ufl.cise.plc;

import edu.ufl.cise.plc.ast.*;
import edu.ufl.cise.plc.runtime.PLCRuntimeException;

//TODO::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::REMOVE THIS LATER
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.Objects;

import edu.ufl.cise.plc.runtime.ColorTuple;
import edu.ufl.cise.plc.runtime.javaCompilerClassLoader.PLCLangExec;

public class CodeGenVisitor implements ASTVisitor {

    codeBuilder code;

    //constructor with package name
    CodeGenVisitor(String pkgName) {
        code = new codeBuilder(pkgName);
    }

    @Override
    public Object visitProgram(Program program, Object arg) throws Exception {
        //set the class name
        code.setClassName(program.getName());

        //set the return type
        if (program.getReturnType() == Types.Type.IMAGE) {
            code.setReturnType("BufferedImage");
        }
        else if (program.getReturnType() == Types.Type.COLOR) {
            code.setReturnType("ColorTuple");
        }
        else {
            code.setReturnType(type2String(program.getReturnType()));
        }

        //go through to get parameters
        for (NameDef NDnode : program.getParams()) {
            code.addParam( (String) NDnode.visit(this, arg) );
        }

        //Check declarations and statements
        for (ASTNode DASnode : program.getDecsAndStatements()) {
            code.addDecOrStatement( (String) DASnode.visit(this, arg) );
        }

        //return the full put together code string
        return code.getFinalCode();
    }

    @Override
    public Object visitNameDef(NameDef nameDef, Object arg) throws Exception {
        //initialize String for java target code
        String javaND = type2String(nameDef.getType());

        //image, color types are a special case
        if(javaND.equals("image")) {
            code.addImportTarget("java.awt.image.BufferedImage");
            javaND = "BufferedImage";
        } else if (javaND.equals("ColorTuple")) {
            code.addImportTarget("edu.ufl.cise.plc.runtime.ColorTuple");
        }

        //add space to separate type and ident
        javaND += " ";

        //add identifier
        javaND += nameDef.getName();

        return javaND;
    }

    @Override
    public Object visitNameDefWithDim(NameDefWithDim nameDefWithDim, Object arg) throws Exception {
        //initialize String for java target code
        String javaNDWD = type2String(nameDefWithDim.getType());

        //image types are a special case
        if(javaNDWD.equals("image")) {
            code.addImportTarget("java.awt.image.BufferedImage");
            javaNDWD = "BufferedImage";
        }

        //add space to separate type and ident
        javaNDWD += " ";

        //add identifier
        javaNDWD += nameDefWithDim.getName();

        return javaNDWD;
    }

    @Override
    public Object visitVarDeclaration(VarDeclaration declaration, Object arg) throws Exception {
        //initialize String for this declaration in java
        String javaDec = "";

        //no matter what, the name def must be added
        javaDec += declaration.getNameDef().visit(this, null);

        //case for initialized
        if (declaration.getOp() != null) {
            //case for <-
            if (declaration.getOp().getKind() == IToken.Kind.LARROW) {
                //image case
                if (declaration.getNameDef().getType() == Types.Type.IMAGE) {
                    if (declaration.getNameDef().getDim() != null) {
                        code.addImportTarget("edu.ufl.cise.plc.runtime.FileURLIO");
                        code.addImportTarget("edu.ufl.cise.plc.runtime.ImageOps");

                        javaDec += " = ImageOps.resize(FileURLIO.readImage(" + declaration.getExpr().visit(this, arg)
                                + ")," + declaration.getNameDef().getDim().visit(this, arg) +")";
                    }
                    else {
                        code.addImportTarget("edu.ufl.cise.plc.runtime.FileURLIO");

                        javaDec += " = FileURLIO.readImage(" + declaration.getExpr().visit(this, arg) + ")";
                    }
                }
                //color case
                else if (declaration.getNameDef().getType() == Types.Type.COLOR) {
                    code.addImportTarget("edu.ufl.cise.plc.runtime.FileURLIO");

                    javaDec += " = (" + type2String(declaration.getNameDef().getType()) + ") FileURLIO.readValueFromFile(" + declaration.getExpr().visit(this, arg) + ")";
                }
                //primitive cases
                else {
                    if (declaration.getExpr().getType() == Types.Type.STRING) {
                        code.addImportTarget("edu.ufl.cise.plc.runtime.FileURLIO");

                        javaDec += " = (" + type2String(declaration.getNameDef().getType()) + ") FileURLIO.readValueFromFile(" + declaration.getExpr().visit(this, arg) +")";
                    }
                    else {
                        javaDec += " = (" + type2String(declaration.getNameDef().getType()) + ") " + declaration.getExpr().visit(this, arg);
                    }
                }
            }
            //case for =
            else {
                //image, image AND resize necessary
                if (declaration.getNameDef().getType() == Types.Type.IMAGE && declaration.getExpr().getType() == Types.Type.IMAGE && declaration.getNameDef().getDim() != null) {
                    code.addImportTarget("edu.ufl.cise.plc.runtime.ImageOps");

                    javaDec += " = ImageOps.resize(" + declaration.getExpr().visit(this, arg)
                            + "," + declaration.getNameDef().getDim().visit(this, arg) +")";
                }
                //image, color
                else if (declaration.getNameDef().getType() == Types.Type.IMAGE && (declaration.getExpr().getType() == Types.Type.COLOR || declaration.getExpr().getCoerceTo() == Types.Type.COLOR)) {
                    code.addImportTarget("edu.ufl.cise.plc.runtime.ImageOps");
                    code.addImportTarget("java.awt.image.BufferedImage");
                    code.addImportTarget("edu.ufl.cise.plc.runtime.ColorTuple");

                    //do assigning on separate line
                    javaDec += " = new BufferedImage(" + declaration.getNameDef().getDim().visit(this, arg)
                            + ", BufferedImage.TYPE_INT_RGB);\n          ";

                    javaDec += "for (int w = 0; w < " + declaration.getNameDef().getDim().getWidth().visit(this, arg) + "; w++) {" +
                            "for (int h = 0; h < " + declaration.getNameDef().getDim().getHeight().visit(this, arg)  + "; h++) {\n" +
                            "               ImageOps.setColor(" + declaration.getName() + ", w, h, " + declaration.getExpr().visit(this, arg)+ ");" +
                            "}}";
                }
                //all else
                else {
                    javaDec += " = " + declaration.getExpr().visit(this, arg);
                }
            }
        }
        //case for uninitialized
        else {
            //case for image (assumed DIMENSION bc type checker)
            if (declaration.getNameDef().getType() == Types.Type.IMAGE) {
                javaDec += " = new BufferedImage(" + declaration.getNameDef().getDim().visit(this, arg)
                            + ", BufferedImage.TYPE_INT_RGB)";
            }
        }

        return javaDec;
    }

    @Override
    public Object visitConditionalExpr(ConditionalExpr conditionalExpr, Object arg) throws Exception {
        //initialize java conditional code String
        String javaCond = "(";

        //check if type casting is necessary
        boolean casted = false;
        if (conditionalExpr.getCoerceTo() != null && conditionalExpr.getCoerceTo() != conditionalExpr.getType()) {
            javaCond += "(" + type2String(conditionalExpr.getCoerceTo()) + ") (";
            casted = true;
        }

        //initialize the java conditional expr String
        javaCond += "(";

        //add the java code for the conditional expr
        javaCond += conditionalExpr.getCondition().visit(this, null);

        //more formatting
        javaCond += ") ? ";

        //add true case
        javaCond += conditionalExpr.getTrueCase().visit(this, null);

        //more formatting
        javaCond += " : ";

        //add false case
        javaCond += conditionalExpr.getFalseCase().visit(this, null) + ")";

        //close out parenthesis if was casted
        if (casted) {
            javaCond += ")";
        }

        return javaCond;
    }

    @Override
    public Object visitBinaryExpr(BinaryExpr binaryExpr, Object arg) throws Exception {
        //initialize binary expr in java String
        String javaBin = "(";

        //check if type casting is necessary
        boolean casted = false;
        if (binaryExpr.getCoerceTo() != null && binaryExpr.getCoerceTo() != binaryExpr.getType()) {
            javaBin += "(" + type2String(binaryExpr.getCoerceTo()) + ") (";
            casted = true;

            //check necessary colortuple import
            if (javaBin.contains("ColorTuple")) {
                code.addImportTarget("edu.ufl.cise.plc.runtime.ColorTuple");
            }
        }

        //save op token and each side kind for reference
        IToken.Kind opK = binaryExpr.getOp().getKind();
        Types.Type lt = binaryExpr.getLeft().getType();
        Types.Type lct = binaryExpr.getLeft().getCoerceTo();
        Types.Type rt = binaryExpr.getRight().getType();
        Types.Type rct = binaryExpr.getRight().getCoerceTo();

        //case for color to color stuff
        if (((lt == Types.Type.COLOR) || (lt == Types.Type.COLORFLOAT) || (lct == Types.Type.COLOR) || (lct == Types.Type.COLORFLOAT))
                &&
                ((rt == Types.Type.COLOR) || (rt == Types.Type.COLORFLOAT) || (rct == Types.Type.COLOR) || (rct == Types.Type.COLORFLOAT))) {
            code.addImportTarget("edu.ufl.cise.plc.runtime.ImageOps");

            if (binaryExpr.getCoerceTo() == Types.Type.INT) {
                javaBin += "(ImageOps.binaryTupleOp(ImageOps." + opKind2String(opK) + ", "
                        + binaryExpr.getLeft().visit(this, arg) + ", " + binaryExpr.getRight().visit(this, arg) + ")).pack()";
            }
            else {
                javaBin += "ImageOps.binaryTupleOp(ImageOps." + opKind2String(opK) + ", "
                        + binaryExpr.getLeft().visit(this, arg) + ", " + binaryExpr.getRight().visit(this, arg) + ")";
            }
        }
        //case for image to image stuff
        else if (lt == Types.Type.IMAGE && rt == Types.Type.IMAGE) {
            code.addImportTarget("edu.ufl.cise.plc.runtime.ImageOps");

            if (opK == IToken.Kind.EQUALS || opK == IToken.Kind.NOT_EQUALS){
                code.addImportTarget("edu.ufl.cise.plc.runtime.imageCheck");

                if (opK == IToken.Kind.NOT_EQUALS) {
                    javaBin += "!";
                }

                javaBin += "imageCheck.equals(" + binaryExpr.getLeft().visit(this, arg) + ", "
                        + binaryExpr.getRight().visit(this, arg) + ")";
            }
            else {
                javaBin += "ImageOps.binaryImageImageOp(ImageOps." + opKind2String(opK) + ", "
                        + binaryExpr.getLeft().visit(this, arg) + ", " + binaryExpr.getRight().visit(this, arg) + ")";
            }
        }
        //case for image to int/float stuff
        else if (lt == Types.Type.IMAGE && (rt == Types.Type.INT || rt == Types.Type.FLOAT)) {
            code.addImportTarget("edu.ufl.cise.plc.runtime.ImageOps");

            javaBin += "ImageOps.binaryImageScalarOp(ImageOps." + opKind2String(opK) + ", "
                    + binaryExpr.getLeft().visit(this, arg) + ", (int) " + binaryExpr.getRight().visit(this, arg) + ")";
        }
        //case for string to string stuff
        else if (lt == Types.Type.STRING && rt == Types.Type.STRING) {
            if (opK == IToken.Kind.NOT_EQUALS) {
                javaBin += "!";
            }
            javaBin += binaryExpr.getLeft().visit(this, arg) + ".equals(" + binaryExpr.getRight().visit(this, null) + ")";
        }
        //int to color cast case
        else if (binaryExpr.getCoerceTo() == Types.Type.COLOR && binaryExpr.getType() == Types.Type.INT) {
            javaBin += "new ColorTuple(" + binaryExpr.getLeft().visit(this, null) + binaryExpr.getOp().getText() + binaryExpr.getRight().visit(this, null) + ")";
        }
        //all remaining cases
        else {
            //add token
            javaBin += binaryExpr.getLeft().visit(this, null) + binaryExpr.getOp().getText() + binaryExpr.getRight().visit(this, null);
        }

        //formatting
        javaBin += ")";
        if (casted) {
            javaBin += ")";
        }

        return javaBin;
    }

    @Override
    public Object visitBooleanLitExpr(BooleanLitExpr booleanLitExpr, Object arg) throws Exception {
        return (booleanLitExpr.getValue()) ? "true" : "false";
    }

    @Override
    public Object visitStringLitExpr(StringLitExpr stringLitExpr, Object arg) throws Exception {
        //initialize java String as three quotes
        String javaStr = "\"\"\"\n";

        //add the string literal value
        javaStr += stringLitExpr.getValue();

        //close string
        javaStr += "\"\"\"";

        return javaStr;
    }

    @Override
    public Object visitIntLitExpr(IntLitExpr intLitExpr, Object arg) throws Exception {
        //initialize String
        String javaInt = "";

        //check if it needs casting
        if (intLitExpr.getCoerceTo() != null) {
            switch (intLitExpr.getCoerceTo()) {
                case COLOR -> javaInt += "new ColorTuple(" + intLitExpr.getValue() + ")";
                case FLOAT -> javaInt += intLitExpr.getValue() + ".0f";
                default -> throw new PLCException("Unhandled coercion type on int literal.");
            }
        } else {
            javaInt += intLitExpr.getValue();
        }

        return javaInt;
    }

    @Override
    public Object visitFloatLitExpr(FloatLitExpr floatLitExpr, Object arg) throws Exception {
        //initialize String
        String javaFloat = "";

        //check if it needs casting
        if (floatLitExpr.getCoerceTo() != null) {
            switch (floatLitExpr.getCoerceTo()) {
                case COLORFLOAT -> javaFloat += "new ColorTupleFloat(" + floatLitExpr.getValue() + "f)";
                default -> throw new PLCException("Unhandled coercion type for float literal.");
            }
        } else {
            javaFloat += floatLitExpr.getValue() + "f";
        }

        return javaFloat;
    }

    @Override
    public Object visitColorConstExpr(ColorConstExpr colorConstExpr, Object arg) throws Exception {
        //import necessary package
        code.addImportTarget("java.awt.Color");
        code.addImportTarget("edu.ufl.cise.plc.runtime.ColorTuple");

        return "ColorTuple.unpack(Color." + colorConstExpr.getText() + ".getRGB())";
    }

    @Override
    public Object visitConsoleExpr(ConsoleExpr consoleExpr, Object arg) throws Exception {
        //add necessary console import
        code.addImportTarget("edu.ufl.cise.plc.runtime.ConsoleIO");

        //initialize the java String
        String javaCon = "";

        //special case for importing images
        if (consoleExpr.getCoerceTo() == Types.Type.IMAGE) {
            javaCon += "(String) ";
        }

        //add <boxed(coerceTo)>
        switch (consoleExpr.getCoerceTo()) {
            case INT -> javaCon += "(Integer) ";
            case FLOAT -> javaCon += "(Float) ";
            case BOOLEAN -> javaCon += "(Boolean) ";
            case STRING -> javaCon += "(String) ";
            case COLOR -> javaCon += "(ColorTuple) ";
            case IMAGE -> javaCon += "";
            default -> throw new PLCRuntimeException("Functionality to implement console expr to "
                    + type2String(consoleExpr.getCoerceTo()) + "not yet supported.");
        }

        //add console scope
        javaCon += "ConsoleIO.readValueFromConsole(";

        //add first argument
        if (consoleExpr.getCoerceTo() == Types.Type.IMAGE) {
            javaCon += "\"STRING\", ";
        }
        else {
            javaCon += "\"" + type2StringCAPS(consoleExpr.getCoerceTo()) + "\", ";
        }

        //add prompt
        javaCon += "\"Enter " + type2String(consoleExpr.getCoerceTo()) + ":\")";

        return javaCon;
    }

    @Override
    public Object visitColorExpr(ColorExpr colorExpr, Object arg) throws Exception {
        code.addImportTarget("edu.ufl.cise.plc.runtime.ColorTuple");
        code.addImportTarget("edu.ufl.cise.plc.runtime.ColorTupleFloat");

        if (colorExpr.getCoerceTo() == Types.Type.INT) {
            return "(new ColorTuple(" + colorExpr.getRed().visit(this, arg) + ","
                    + colorExpr.getGreen().visit(this, arg) + ","
                    + colorExpr.getBlue().visit(this, arg) + ")).pack()";
        }
        else if (colorExpr.getCoerceTo() == Types.Type.COLORFLOAT && colorExpr.getType() == Types.Type.COLOR) {
            return "new ColorTupleFloat(" + colorExpr.getRed().visit(this, arg) + ","
                    + colorExpr.getGreen().visit(this, arg) + ","
                    + colorExpr.getBlue().visit(this, arg) + ")";
        }
        else if (colorExpr.getCoerceTo() == Types.Type.COLOR && colorExpr.getType() == Types.Type.COLORFLOAT) {
            return "new ColorTuple( (int)" + colorExpr.getRed().visit(this, arg) + ", (int) "
                    + colorExpr.getGreen().visit(this, arg) + ", (int) "
                    + colorExpr.getBlue().visit(this, arg) + ")";
        }
        else {
            return "new ColorTuple(" + colorExpr.getRed().visit(this, arg) + ","
                    + colorExpr.getGreen().visit(this, arg) + ","
                    + colorExpr.getBlue().visit(this, arg) + ")";
        }
    }

    @Override
    public Object visitUnaryExpr(UnaryExpr unaryExpression, Object arg) throws Exception {
        //initialize java String for unaryExpr
        String javaUnary = "(";

        //check if casting is necessary
        boolean casted = false;
        if (unaryExpression.getCoerceTo()!=null && unaryExpression.getCoerceTo() != unaryExpression.getType()){
            javaUnary += "(" + type2String(unaryExpression.getCoerceTo()) + ") (";
            casted = true;
        }

        //add token operator
        switch (unaryExpression.getOp().getKind()) {
            case MINUS -> {
                javaUnary += "-" + unaryExpression.getExpr().visit(this, null);
            }
            case BANG -> {
                javaUnary += "!" + unaryExpression.getExpr().visit(this, null);

            }
            case COLOR_OP -> {
                switch (unaryExpression.getExpr().getType()) {
                    case INT, COLOR -> {
                        code.addImportTarget("edu.ufl.cise.plc.runtime.ColorTuple");
                        javaUnary += "ColorTuple." + unaryExpression.getOp().getText() + "(" + unaryExpression.getExpr().visit(this, arg) + ")";
                    }
                    case COLORFLOAT -> {
                        code.addImportTarget("edu.ufl.cise.plc.runtime.ColorTupleFloat");
                        switch (unaryExpression.getOp().getText()) {
                            case "getRed" -> javaUnary += "ColorTupleFloat.red(" + unaryExpression.getExpr().visit(this, arg) + ")";
                            case "getGreen" -> javaUnary += "ColorTupleFloat.green(" + unaryExpression.getExpr().visit(this, arg) + ")";
                            case "getBlue" -> javaUnary += "ColorTupleFloat.blue(" + unaryExpression.getExpr().visit(this, arg) + ")";
                        }
                    }
                    case IMAGE -> {
                        code.addImportTarget("edu.ufl.cise.plc.runtime.ImageOps");
                        switch (unaryExpression.getOp().getText()) {
                            case "getRed" -> {
                                javaUnary += "ImageOps.extractRed(" + unaryExpression.getExpr().visit(this, arg) + ")";;
                            }
                            case "getGreen" -> {
                                javaUnary += "ImageOps.extractGreen(" + unaryExpression.getExpr().visit(this, arg) + ")";;
                            }
                            case "getBlue" -> {
                                javaUnary += "ImageOps.extractBlue(" + unaryExpression.getExpr().visit(this, arg) + ")";;
                            }
                        }
                    }
                }
            }
            case IMAGE_OP -> {
                switch (unaryExpression.getOp().getText()) {
                    case "getWidth" -> javaUnary += unaryExpression.getExpr().visit(this, arg) + ".getWidth()";
                    case "getHeight" -> javaUnary += unaryExpression.getExpr().visit(this, arg) + ".getHeight()";
                }
            }
            default -> throw new PLCRuntimeException("UnaryExpr encountered with unsupported operator kind");
        }

        //formatting
        javaUnary += ")";
        if (casted) { javaUnary += ")"; }

        return javaUnary;
    }

    @Override
    public Object visitIdentExpr(IdentExpr identExpr, Object arg) throws Exception {
        //initialize String
        String javaIdent = "";

        //check if it needs casting
        if (identExpr.getCoerceTo() != null && identExpr.getCoerceTo() != identExpr.getType()) {
            if (identExpr.getCoerceTo() == Types.Type.INT && identExpr.getType() == Types.Type.COLOR) {
                javaIdent += identExpr.getText() + ".pack()";
            }
            else if (identExpr.getCoerceTo() == Types.Type.COLOR && identExpr.getType() == Types.Type.INT) {
                javaIdent += "new ColorTuple(" + identExpr.getText() + ")";
            }
            else if (identExpr.getCoerceTo() == Types.Type.COLORFLOAT && (identExpr.getType() == Types.Type.COLOR || identExpr.getType() == Types.Type.INT)) {
                code.addImportTarget("edu.ufl.cise.plc.runtime.ColorTupleFloat");

                javaIdent += "new ColorTupleFloat( (float) ColorTuple.getRed(" + identExpr.getText() + "),"
                                                + "(float) ColorTuple.getGreen(" + identExpr.getText() + "),"
                                                + "(float) ColorTuple.getBlue(" + identExpr.getText() + "))";
            }
            else {
                javaIdent += "(" + type2String(identExpr.getCoerceTo()) + ") " + identExpr.getText();
            }
        }
        else {
            javaIdent += identExpr.getText();
        }

        return javaIdent;
    }

    @Override
    public Object visitDimension(Dimension dimension, Object arg) throws Exception {
        //this function gets a string for the width and height expressions
        String dimensions = "";

        //get first (width)
        dimensions += dimension.getWidth().visit(this, arg);

        //add comma
        dimensions += ",";

        //get second (height)
        dimensions += dimension.getHeight().visit(this, arg);

        return dimensions;
    }

    @Override
    public Object visitPixelSelector(PixelSelector pixelSelector, Object arg) throws Exception {
        //RIGHT SIDE CASE ONLY
        String javaPSright = "";
        //get first (width)
        javaPSright += pixelSelector.getX().visit(this, arg);
        //add comma
        javaPSright += ",";
        //get second (height)
        javaPSright += pixelSelector.getY().visit(this, arg);
        return javaPSright;
    }

    @Override
    public Object visitAssignmentStatement(AssignmentStatement assignmentStatement, Object arg) throws Exception {
        //initialize code string
        String javaAssn = "";

        //case for both sides being images
        if (assignmentStatement.getTargetDec().getType() == Types.Type.IMAGE && assignmentStatement.getExpr().getType() == Types.Type.IMAGE) {
            code.addImportTarget("edu.ufl.cise.plc.runtime.ImageOps");
            javaAssn += assignmentStatement.getName() + " = ";

            if (assignmentStatement.getTargetDec().getDim() != null) {
                javaAssn += "ImageOps.resize(" + assignmentStatement.getExpr().visit(this, arg) + ","
                        + assignmentStatement.getTargetDec().getDim().visit(this, arg) + ")";
            }
            else {
                javaAssn += "ImageOps.clone(" + assignmentStatement.getExpr().visit(this, arg) + ")";
            }
        }
        //case for LHS image with pixel selector
        else if (assignmentStatement.getTargetDec().getType() == Types.Type.IMAGE && assignmentStatement.getSelector() != null) {
            code.addImportTarget("edu.ufl.cise.plc.runtime.ImageOps");
            code.addImportTarget("edu.ufl.cise.plc.runtime.ColorTuple");

            //case for LHS image and RHS coerce to color
            if (assignmentStatement.getExpr().getType() == Types.Type.COLOR || assignmentStatement.getExpr().getCoerceTo() == Types.Type.COLOR) {
                javaAssn += "for (int " + assignmentStatement.getSelector().getX().visit(this, arg) + " = 0; " + assignmentStatement.getSelector().getX().visit(this, arg) + " < " + assignmentStatement.getName() + ".getWidth(); " + assignmentStatement.getSelector().getX().visit(this, arg) + "++) {" +
                        "for (int " + assignmentStatement.getSelector().getY().visit(this, arg) + " = 0; " + assignmentStatement.getSelector().getY().visit(this, arg) + " < " + assignmentStatement.getName() + ".getHeight(); " + assignmentStatement.getSelector().getY().visit(this, arg) + "++) {\n" +
                        "               ImageOps.setColor(" + assignmentStatement.getName() + "," + assignmentStatement.getSelector().getX().visit(this, arg) + "," + assignmentStatement.getSelector().getY().visit(this, arg) + "," + assignmentStatement.getExpr().visit(this, arg)+ ");" +
                        "}}";
            }
        }
        //case for LHS image WO pixel selector
        else if (assignmentStatement.getTargetDec().getType() == Types.Type.IMAGE && assignmentStatement.getSelector() == null) {
            //case for LHS image and RHS coerce to color/int
            code.addImportTarget("edu.ufl.cise.plc.runtime.ImageOps");
            code.addImportTarget("edu.ufl.cise.plc.runtime.ColorTuple");

            javaAssn += "for (int w = 0; w < " + assignmentStatement.getName() + ".getWidth(); w++) { for (int h = 0; h < " + assignmentStatement.getName() + ".getHeight(); h++) {" +
                    "ImageOps.setColor(" + assignmentStatement.getName() + ", w, h, " + assignmentStatement.getExpr().visit(this, arg) + ");" +
                    "}}";
        }
        //all other cases where LHS is not image
        else {
            javaAssn += assignmentStatement.getName() + " = " + assignmentStatement.getExpr().visit(this, arg);
        }

        return javaAssn;
    }

    @Override
    public Object visitWriteStatement(WriteStatement writeStatement, Object arg) throws Exception {
        //start string
        String javaWrite = "";

        //first case for handling image types
        if (writeStatement.getSource().getType() == Types.Type.IMAGE) {
            if (writeStatement.getDest().getFirstToken().getKind() == IToken.Kind.KW_CONSOLE) {
                code.addImportTarget("edu.ufl.cise.plc.runtime.ConsoleIO");
                javaWrite += "ConsoleIO.displayImageOnScreen(" + writeStatement.getSource().visit(this, arg) + ")";
            } else if (writeStatement.getDest().getType() == Types.Type.STRING){
                code.addImportTarget("edu.ufl.cise.plc.runtime.FileURLIO");
                javaWrite += "FileURLIO.writeImage(" + writeStatement.getSource().visit(this, arg) + ", "
                                + writeStatement.getDest().visit(this, arg) + ")";
            }
        //remaining cases for handling all non-image types
        } else {
            if (writeStatement.getDest().getFirstToken().getKind() == IToken.Kind.KW_CONSOLE) {
                code.addImportTarget("edu.ufl.cise.plc.runtime.ConsoleIO");
                javaWrite += "ConsoleIO.console.println(" + writeStatement.getSource().visit(this, arg) + ")";
            }
            else if (writeStatement.getDest().getType() == Types.Type.STRING){
                code.addImportTarget("edu.ufl.cise.plc.runtime.FileURLIO");
                javaWrite += "FileURLIO.writeValue(" + writeStatement.getSource().visit(this, arg) + ", "
                                + writeStatement.getDest().visit(this, arg) + ")";
            }
        }

        return javaWrite;
    }

    @Override
    public Object visitReadStatement(ReadStatement readStatement, Object arg) throws Exception {
        //initialize the java String with IDENT
        String javaRead = readStatement.getName() + " = ";

        //LHS image case
        if (readStatement.getTargetDec().getType() == Types.Type.IMAGE) {
            //case for resize
            if (readStatement.getTargetDec().getDim() != null) {
                code.addImportTarget("edu.ufl.cise.plc.runtime.FileURLIO");
                code.addImportTarget("edu.ufl.cise.plc.runtime.ImageOps");

                javaRead += "ImageOps.resize(FileURLIO.readImage(" + readStatement.getSource().visit(this, arg) + "),"
                            + readStatement.getTargetDec().getDim().visit(this, arg) + ")";
            }
            //no resize needed
            else {
                code.addImportTarget("edu.ufl.cise.plc.runtime.FileURLIO");

                javaRead += "FileURLIO.readImage(" + readStatement.getSource().visit(this, arg) + ")";
            }
        }
        //non-image RHS string (from file)
        else if (readStatement.getSource().getType() == Types.Type.STRING) {
            code.addImportTarget("edu.ufl.cise.plc.runtime.FileURLIO");

            javaRead += "(" + type2String(readStatement.getTargetDec().getType()) + ") FileURLIO.readValueFromFile(" + readStatement.getSource().visit(this, arg) + ")";
        }
        else {
            javaRead += readStatement.getSource().visit(this, null);
        }

        return javaRead;
    }

    @Override
    public Object visitReturnStatement(ReturnStatement returnStatement, Object arg) throws Exception {
        //initialize java return command string
        String javaR = "return ";

        //add the expr
        javaR += returnStatement.getExpr().visit(this, null);

        return javaR;
    }

    @Override
    public Object visitUnaryExprPostfix(UnaryExprPostfix unaryExprPostfix, Object arg) throws Exception {
        //start string
        String javaUEPF = "";

        //image and pixel selector case
        if (unaryExprPostfix.getExpr().getType() == Types.Type.IMAGE && unaryExprPostfix.getSelector() != null) {
            code.addImportTarget("edu.ufl.cise.plc.runtime.ColorTuple");

            javaUEPF += "ColorTuple.unpack(" + unaryExprPostfix.getExpr().visit(this, arg) + ".getRGB(" + unaryExprPostfix.getSelector().visit(this, arg)
                    + "))";
        }
        //all other cases (image and non-image) where no PS present
        else {
            javaUEPF += unaryExprPostfix.getExpr().visit(this, arg);
        }

        return javaUEPF;
    }

    //helper function to convert type to String
    private String type2String (Types.Type t) {
        return switch(t) {
            case BOOLEAN -> "boolean";
            case COLOR -> "ColorTuple";
            case CONSOLE -> "console";
            case FLOAT -> "float";
            case IMAGE -> "image";
            case INT -> "int";
            case STRING -> "String";
            case VOID -> "void";
            case COLORFLOAT -> "ColorTupleFloat";
        };
    }

    //helper function to convert Kind to String
    private String opKind2String (IToken.Kind k) {
        return switch (k) {
            case PLUS -> "OP.PLUS";
            case MINUS -> "OP.MINUS";
            case TIMES -> "OP.TIMES";
            case DIV -> "OP.DIV";
            case MOD -> "OP.MOD";
            case EQUALS -> "BoolOP.EQUALS";
            case NOT_EQUALS -> "BoolOP.NOT_EQUALS";
            default -> "BAD OP KIND";
        };
    }

    private String type2StringCAPS (Types.Type t) {
        return switch(t) {
            case BOOLEAN -> "BOOLEAN";
            case COLOR -> "COLOR";
            case CONSOLE -> "CONSOLE";
            case FLOAT -> "FLOAT";
            case IMAGE -> "IMAGE";
            case INT -> "INT";
            case STRING -> "STRING";
            case VOID -> "VOID";
            case COLORFLOAT -> "COLORFLOAT";
        };
    }

}
