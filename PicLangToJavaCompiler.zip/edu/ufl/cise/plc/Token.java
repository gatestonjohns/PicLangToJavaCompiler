package edu.ufl.cise.plc;

public class Token implements IToken {
    final Kind kind;
    final String input;
    final int line;
    final int column;

    //constructor
    public Token(Kind kind, String input, int line, int column) {
        this.kind = kind;
        this.input = input;
        this.line = line;
        this.column = column;
        //TODO: incorporate source location
    }

    //overridden functions
    @Override
    public Kind getKind() { return kind; }

    @Override
    public String getText() { return input; }

    @Override
    public IToken.SourceLocation getSourceLocation() {
        return new IToken.SourceLocation(line, column);
    };

    @Override
    public int getIntValue() {
        return Integer.parseInt(input);
    }

    @Override
    public float getFloatValue() {
        return Float.parseFloat(input);
    }

    @Override
    public boolean getBooleanValue() { return Boolean.parseBoolean(this.getText()); }

    @Override
    public String getStringValue() {
        //start with empty string and get string to process (remove "" ends)
        String s = "", unprocessed = input.substring(1, input.length() - 1);

        //process the escape chars
        for(int i = 0; i < unprocessed.length(); i++) {
            if (unprocessed.charAt(i) == '\\') {
                switch (unprocessed.charAt(++i)) {
                    case 'b' -> {
                        s += (char)8;
                    }
                    case 't' -> {
                        s += (char)9;
                    }
                    case 'f' -> {
                        s += (char)12;
                    }
                    case 'n' -> {
                        s += (char)10;
                    }
                    case 'r' -> {
                        s += (char)13;
                    }
                    case '\\' -> {
                        s += '\\';
                    }
                    case '\'' -> {
                        s += '\'';
                    }
                    case '\"' -> {
                        s += '\"';
                    }
                }
            }
            else {
                s += unprocessed.charAt(i);
            }
        }

        //return answer
        return s;
    }
}
